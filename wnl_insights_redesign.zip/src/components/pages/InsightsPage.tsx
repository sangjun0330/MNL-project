"use client";

import Link from "next/link";
import { useMemo } from "react";
import { cn } from "@/lib/cn";
import { formatKoreanDate } from "@/lib/date";
import { statusColor, statusLabel } from "@/lib/wnlInsight";
import { useInsightsData, shiftKo } from "@/components/insights/useInsightsData";
import { Card } from "@/components/ui/Card";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6">
      <div className="mb-2 text-[13px] font-semibold text-ios-sub">{title}</div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function SummaryCard({
  href,
  label,
  title,
  summary,
  meta,
  value,
  valueLabel,
  valueColor,
}: {
  href: string;
  label: string;
  title: string;
  summary: string;
  meta?: React.ReactNode;
  value?: string | number;
  valueLabel?: string;
  valueColor?: string;
}) {
  return (
    <Link
      href={href}
      className={cn(
        "group block rounded-apple border border-ios-sep bg-white p-5",
        "transition-shadow duration-300 hover:shadow-apple"
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-[12px] font-semibold text-ios-sub">{label}</div>
          <div className="mt-1 text-[17px] font-semibold tracking-[-0.01em] text-ios-text">
            {title}
          </div>
          <div className="mt-1 text-[13px] text-ios-sub">{summary}</div>
        </div>
        <div className="mt-0.5 text-[22px] text-ios-muted transition group-hover:text-ios-text">›</div>
      </div>

      {typeof value !== "undefined" ? (
        <div className="mt-4 flex items-end gap-2">
          <div
            className="text-[28px] font-extrabold tracking-[-0.02em]"
            style={valueColor ? { color: valueColor } : undefined}
          >
            {value}
          </div>
          {valueLabel ? <div className="pb-1 text-[12.5px] text-ios-muted">{valueLabel}</div> : null}
        </div>
      ) : null}

      {meta ? <div className="mt-3 flex flex-wrap items-center gap-2">{meta}</div> : null}
    </Link>
  );
}

function MetaPill({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full border border-ios-sep bg-white px-3 py-1 text-[12px] font-semibold text-ios-sub">
      {children}
    </span>
  );
}

export function InsightsPage() {
  const {
    end,
    todayShift,
    menstrual,
    todayDisplay,
    status,
    syncLabel,
    avgDisplay,
    avgBody,
    avgMental,
    top1,
    top3,
    ordersSummary,
  } = useInsightsData();

  const recoverySummary = useMemo(() => {
    if (!top1) return "기록이 쌓이면 회복 처방이 더 정교해져요.";
    return `회복 포커스: ${top1.label} · ${Math.round(top1.pct * 100)}%`;
  }, [top1]);

  const thievesSummary = useMemo(() => {
    if (!top1) return "방전 요인을 분석할 데이터가 부족해요.";
    return `${top1.label} 비중 ${Math.round(top1.pct * 100)}%`;
  }, [top1]);

  const trendSummary = useMemo(() => `최근 7일 평균 Vital ${avgDisplay}`, [avgDisplay]);

  return (
    <div className="mx-auto w-full max-w-[920px] px-4 pb-24 pt-6 sm:px-6">
      <div className="mb-4">
        <div className="text-[32px] font-extrabold tracking-[-0.03em]">Summary</div>
        <div className="mt-1 flex flex-wrap items-center gap-2 text-[13px] text-ios-sub">
          <span>{formatKoreanDate(end)}</span>
          <span className="opacity-40">·</span>
          <span>{shiftKo(todayShift)}</span>
          <span className="opacity-40">·</span>
          <span>{menstrual.enabled ? menstrual.label : "주기"}</span>
          <span className="opacity-40">·</span>
          <span>Vital {todayDisplay}</span>
        </div>
      </div>

      <Card className="p-5">
        <div className="text-[13px] font-semibold text-ios-sub">Recovery Focus</div>
        <div className="mt-1 text-[18px] font-semibold tracking-[-0.02em]">
          오늘 회복의 핵심을 빠르게 확인하세요
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <MetaPill>{syncLabel}</MetaPill>
          {top3?.map((t) => (
            <MetaPill key={t.key}>
              TOP · {t.label} {Math.round(t.pct * 100)}%
            </MetaPill>
          ))}
        </div>
      </Card>

      <Section title="Pinned">
        <SummaryCard
          href="/insights/recovery"
          label="Personalized Recovery"
          title="맞춤 회복 처방"
          summary={recoverySummary}
          meta={(
            <>
              <MetaPill>최근 7일 기준</MetaPill>
              <MetaPill>맞춤 오더 제공</MetaPill>
            </>
          )}
        />
        <SummaryCard
          href="/insights/orders"
          label="Dr. WNL's Orders"
          title="오늘 오더"
          summary={ordersSummary.headline}
          meta={(
            <>
              <MetaPill>처방 {ordersSummary.count}개</MetaPill>
              <MetaPill>{shiftKo(todayShift)}</MetaPill>
            </>
          )}
        />
      </Section>

      <Section title="Trends">
        <SummaryCard
          href="/insights/trends"
          label="Stats"
          title="최근 7일 통계"
          summary={trendSummary}
          meta={(
            <>
              <MetaPill>Body {avgBody}</MetaPill>
              <MetaPill>Mental {avgMental}</MetaPill>
            </>
          )}
        />
        <SummaryCard
          href="/insights/thieves"
          label="Battery Thieves"
          title="에너지 도둑"
          summary={thievesSummary}
          meta={<MetaPill>피로 요인 집중 분석</MetaPill>}
        />
      </Section>

      <Section title="Plan">
        <SummaryCard
          href="/insights/timeline"
          label="Timeline Forecast"
          title="타임라인 예보"
          summary={`${shiftKo(todayShift)} 기준 회복 흐름 예보`}
          meta={<MetaPill>오늘의 리듬 가이드</MetaPill>}
        />
      </Section>

      <Section title="Vitals">
        <SummaryCard
          href="/insights/vital"
          label="WNL Vital"
          title="오늘 바이탈"
          summary={statusLabel(status)}
          value={todayDisplay}
          valueLabel="/ 100"
          valueColor={statusColor(status)}
        />
      </Section>
    </div>
  );
}
