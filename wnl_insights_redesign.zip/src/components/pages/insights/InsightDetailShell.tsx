import Link from "next/link";
import { cn } from "@/lib/cn";

export function InsightDetailShell({
  title,
  subtitle,
  meta,
  children,
  right,
  className,
}: {
  title: string;
  subtitle?: string;
  meta?: React.ReactNode;
  children: React.ReactNode;
  right?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mx-auto w-full max-w-[920px] px-4 pb-24 pt-5 sm:px-6", className)}>
      <div className="mb-5 flex items-center gap-3">
        <Link
          href="/insights"
          className="flex h-9 w-9 items-center justify-center rounded-full border border-ios-sep bg-white text-[18px] text-ios-text"
          aria-label="Back"
        >
          ‹
        </Link>
        <div className="flex-1 text-center">
          <div className="text-[17px] font-semibold tracking-[-0.01em] text-ios-text">{title}</div>
          {subtitle ? <div className="text-[12.5px] text-ios-muted">{subtitle}</div> : null}
        </div>
        <div className="flex h-9 w-9 items-center justify-center">{right}</div>
      </div>

      {meta ? <div className="mb-4 text-[12.5px] text-ios-sub">{meta}</div> : null}

      {children}
    </div>
  );
}
