"use client";

import { InsightDetailShell } from "@/components/pages/insights/InsightDetailShell";
import { useInsightsData, shiftKo } from "@/components/insights/useInsightsData";
import { formatKoreanDate } from "@/lib/date";
import { OrdersCarousel } from "@/components/insights/v2/OrdersCarousel";
import { Card } from "@/components/ui/Card";

export function InsightsOrdersDetail() {
  const { end, todayShift, todayVital } = useInsightsData();

  return (
    <InsightDetailShell
      title="오늘 오더"
      subtitle={formatKoreanDate(end)}
      meta={`${shiftKo(todayShift)} 기준으로 바로 실행할 처방을 제공합니다.`}
    >
      <Card className="p-5">
        <div className="text-[13px] font-semibold text-ios-sub">Dr. WNL's Orders</div>
        <div className="mt-1 text-[18px] font-semibold tracking-[-0.02em]">지금 당장 실행할 처방</div>
        <div className="mt-2 text-[13px] text-ios-sub">작고 빠른 오더부터 실행하면 회복 효율이 크게 올라갑니다.</div>
      </Card>

      <div className="mt-4">
        <OrdersCarousel vital={todayVital} pivotISO={end} />
      </div>
    </InsightDetailShell>
  );
}
