"use client";

import { InsightDetailShell } from "@/components/pages/insights/InsightDetailShell";
import { useInsightsData } from "@/components/insights/useInsightsData";
import { formatKoreanDate } from "@/lib/date";
import { RecoveryPrescription } from "@/components/insights/RecoveryPrescription";
import { Card } from "@/components/ui/Card";

export function InsightsRecoveryDetail() {
  const { end, state } = useInsightsData();

  return (
    <InsightDetailShell
      title="맞춤 회복 처방"
      subtitle={formatKoreanDate(end)}
      meta="기록(수면/스트레스/활동/카페인/기분/주기)을 근거로 회복 플랜을 제공합니다."
    >
      <Card className="p-5">
        <div className="text-[13px] font-semibold text-ios-sub">Personalized Recovery</div>
        <div className="mt-1 text-[18px] font-semibold tracking-[-0.02em]">오늘부터 다음 듀티까지의 회복 처방</div>
        <div className="mt-2 text-[13px] text-ios-sub">
          입력이 많을수록 더 날카롭고 정확하게 회복 루틴이 설계됩니다.
        </div>
      </Card>

      <div className="mt-4 rounded-apple border border-ios-sep bg-white shadow-apple">
        <div className="px-5 pb-5 pt-4">
          <RecoveryPrescription state={state} pivotISO={end} />
        </div>
      </div>
    </InsightDetailShell>
  );
}
