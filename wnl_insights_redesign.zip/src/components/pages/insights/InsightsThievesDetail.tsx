"use client";

import { InsightDetailShell } from "@/components/pages/insights/InsightDetailShell";
import { useInsightsData } from "@/components/insights/useInsightsData";
import { formatKoreanDate } from "@/lib/date";
import { BatteryThieves } from "@/components/insights/v2/BatteryThieves";

export function InsightsThievesDetail() {
  const { end, vitals } = useInsightsData();

  return (
    <InsightDetailShell
      title="에너지 도둑"
      subtitle={formatKoreanDate(end)}
      meta="회복을 방해하는 핵심 요인을 비율로 분석합니다."
    >
      <BatteryThieves vitals={vitals} periodLabel="최근 7일 기준" />
    </InsightDetailShell>
  );
}
