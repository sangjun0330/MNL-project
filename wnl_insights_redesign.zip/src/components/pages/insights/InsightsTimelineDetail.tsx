"use client";

import { InsightDetailShell } from "@/components/pages/insights/InsightDetailShell";
import { useInsightsData, shiftKo } from "@/components/insights/useInsightsData";
import { formatKoreanDate } from "@/lib/date";
import { TimelineForecast } from "@/components/insights/v2/TimelineForecast";

export function InsightsTimelineDetail() {
  const { end, todayShift, todayVital } = useInsightsData();

  return (
    <InsightDetailShell
      title="타임라인 예보"
      subtitle={formatKoreanDate(end)}
      meta={`${shiftKo(todayShift)} 기준으로 회복 루틴을 시간순으로 제공합니다.`}
    >
      <TimelineForecast pivotISO={end} shift={todayShift} vital={todayVital} />
    </InsightDetailShell>
  );
}
