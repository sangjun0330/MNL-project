"use client";

import { InsightDetailShell } from "@/components/pages/insights/InsightDetailShell";
import { useInsightsData, fmtMD, shiftKo } from "@/components/insights/useInsightsData";
import { formatKoreanDate } from "@/lib/date";
import { TrendChart } from "@/components/insights/TrendChart";
import { Pill } from "@/components/ui/Pill";
import { Card } from "@/components/ui/Card";
import { WNL_COLORS, statusFromScore } from "@/lib/wnlInsight";

export function InsightsTrendsDetail() {
  const { end, avgDisplay, avgBody, avgMental, bestWorst, shiftCounts, trend, top3 } = useInsightsData();

  const status = statusFromScore(avgDisplay);

  return (
    <InsightDetailShell
      title="최근 7일 통계"
      subtitle={formatKoreanDate(end)}
      meta="최근 7일의 리듬/바이탈 변화와 핵심 요인을 정리했습니다."
    >
      <Card className="p-5">
        <div className="text-[13px] font-semibold text-ios-sub">Stats</div>
        <div className="mt-1 text-[18px] font-semibold tracking-[-0.02em]">주간 요약</div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-3">
            <div className="text-[12px] font-semibold text-ios-sub">Avg Vital</div>
            <div
              className="mt-1 text-[22px] font-extrabold"
              style={{
                color:
                  status === "stable"
                    ? WNL_COLORS.mint
                    : status === "caution" || status === "observation"
                    ? WNL_COLORS.yellow
                    : WNL_COLORS.pink,
              }}
            >
              {avgDisplay}
            </div>
          </div>
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-3">
            <div className="text-[12px] font-semibold text-ios-sub">Body</div>
            <div className="mt-1 text-[22px] font-extrabold">{avgBody}</div>
          </div>
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-3">
            <div className="text-[12px] font-semibold text-ios-sub">Mental</div>
            <div className="mt-1 text-[22px] font-extrabold">{avgMental}</div>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          {(top3 ?? []).map((t) => (
            <Pill key={t.key} className="bg-white">
              <span className="text-ios-sub">TOP</span>
              <span className="mx-1 opacity-30">·</span>
              <span className="font-semibold">{t.label}</span>
              <span className="ml-2 text-ios-muted">{Math.round(t.pct * 100)}%</span>
            </Pill>
          ))}
        </div>

        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          <div className="rounded-2xl border border-ios-sep bg-white p-4">
            <div className="text-[12px] font-semibold text-ios-sub">Best</div>
            <div className="mt-1 text-[15px] font-semibold">
              {bestWorst.best
                ? `${fmtMD(bestWorst.best.dateISO)} · ${shiftKo(bestWorst.best.shift)} · Vital ${Math.round(
                    Math.min(bestWorst.best.body.value, bestWorst.best.mental.ema)
                  )}`
                : "-"}
            </div>
          </div>
          <div className="rounded-2xl border border-ios-sep bg-white p-4">
            <div className="text-[12px] font-semibold text-ios-sub">Worst</div>
            <div className="mt-1 text-[15px] font-semibold">
              {bestWorst.worst
                ? `${fmtMD(bestWorst.worst.dateISO)} · ${shiftKo(bestWorst.worst.shift)} · Vital ${Math.round(
                    Math.min(bestWorst.worst.body.value, bestWorst.worst.mental.ema)
                  )}`
                : "-"}
            </div>
          </div>
        </div>

        <div className="mt-3 text-[12.5px] text-ios-muted">
          근무 분포: D {shiftCounts.D} · E {shiftCounts.E} · N {shiftCounts.N} · OFF {shiftCounts.OFF}
        </div>
      </Card>

      <div className="mt-4 rounded-apple border border-ios-sep bg-white shadow-apple">
        <div className="px-5 pt-5">
          <div className="text-[13px] font-semibold text-ios-sub">Trend</div>
          <div className="mt-1 text-[18px] font-semibold tracking-[-0.02em]">에너지 흐름</div>
        </div>
        <div className="px-5 pb-5 pt-4">
          <TrendChart data={trend} />
        </div>
      </div>
    </InsightDetailShell>
  );
}
