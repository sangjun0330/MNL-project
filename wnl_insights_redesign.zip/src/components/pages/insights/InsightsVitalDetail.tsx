"use client";

import { useMemo, useState } from "react";
import { InsightDetailShell } from "@/components/pages/insights/InsightDetailShell";
import { useInsightsData, shiftKo } from "@/components/insights/useInsightsData";
import { formatKoreanDate } from "@/lib/date";
import { HeroDashboard } from "@/components/insights/v2/HeroDashboard";
import { BottomSheet } from "@/components/ui/BottomSheet";
import { Card } from "@/components/ui/Card";
import { FACTOR_LABEL_KO, type FactorKey } from "@/lib/insightsV2";
import { WNL_COLORS } from "@/lib/wnlInsight";

function clamp01(n: number) {
  const v = Number.isFinite(n) ? n : 0;
  return Math.max(0, Math.min(1, v));
}

export function InsightsVitalDetail() {
  const { end, todayShift, todayVital, syncLabel, fastCharge, accuracy } = useInsightsData();
  const [openSync, setOpenSync] = useState(false);

  const body = useMemo(() => Math.round(todayVital?.body.value ?? 0), [todayVital]);
  const mental = useMemo(() => Math.round(todayVital?.mental.ema ?? 0), [todayVital]);
  const debt = useMemo(() => Math.round((todayVital?.engine?.sleepDebtHours ?? 0) * 10) / 10, [todayVital]);
  const srs = useMemo(() => Math.round((todayVital?.engine?.SRS ?? 1) * 100), [todayVital]);
  const cmf = useMemo(() => Math.round((todayVital?.engine?.CMF ?? 0) * 100), [todayVital]);

  return (
    <InsightDetailShell
      title="WNL Vital"
      subtitle={formatKoreanDate(end)}
      meta={`${shiftKo(todayShift)} · 오늘 바이탈 분석`}
      right={(
        <button
          type="button"
          onClick={() => setOpenSync(true)}
          className="rounded-full border border-ios-sep bg-white px-2.5 py-1 text-[11.5px] font-semibold text-ios-sub"
        >
          Sync
        </button>
      )}
    >
      <HeroDashboard vital={todayVital} syncLabel={syncLabel} fastCharge={fastCharge} />

      <Card className="mt-4 p-5">
        <div className="text-[13px] font-semibold text-ios-sub">오늘 상태</div>
        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-3">
            <div className="text-[12px] font-semibold text-ios-sub">Body</div>
            <div className="mt-1 text-[20px] font-extrabold">{body}</div>
          </div>
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-3">
            <div className="text-[12px] font-semibold text-ios-sub">Mental</div>
            <div className="mt-1 text-[20px] font-extrabold">{mental}</div>
          </div>
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-3">
            <div className="text-[12px] font-semibold text-ios-sub">Sleep Debt</div>
            <div className="mt-1 text-[20px] font-extrabold">{debt}h</div>
          </div>
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-3">
            <div className="text-[12px] font-semibold text-ios-sub">SRS / CMF</div>
            <div className="mt-1 text-[18px] font-extrabold">
              {srs}% · {cmf}%
            </div>
          </div>
        </div>
      </Card>

      <BottomSheet
        open={openSync}
        onClose={() => setOpenSync(false)}
        title="프리셉터 싱크(Sync)"
        subtitle="입력률 × 영향도 기반으로 개인화 정확도를 계산합니다."
        maxHeightClassName="max-h-[76dvh]"
      >
        <div className="space-y-4">
          <div className="rounded-2xl border border-ios-sep bg-ios-bg p-4">
            <div className="text-[13px] font-semibold">예측 정확도</div>
            <div className="mt-2 flex items-end justify-between">
              <div
                className="text-[28px] font-extrabold"
                style={{
                  color:
                    accuracy.percent >= 70
                      ? WNL_COLORS.mint
                      : accuracy.percent >= 40
                      ? WNL_COLORS.yellow
                      : WNL_COLORS.pink,
                }}
              >
                {accuracy.percent}%
              </div>
              <div className="text-[12.5px] text-ios-muted">최근 7일 기준</div>
            </div>
            <div className="mt-3 h-2.5 w-full rounded-full bg-white">
              <div
                className="h-2.5 rounded-full"
                style={{
                  width: `${clamp01(accuracy.percent / 100) * 100}%`,
                  backgroundColor:
                    accuracy.percent >= 70
                      ? WNL_COLORS.mint
                      : accuracy.percent >= 40
                      ? WNL_COLORS.yellow
                      : WNL_COLORS.pink,
                }}
              />
            </div>
            {accuracy.missingTop?.length ? (
              <div className="mt-3 text-[12.5px] text-ios-sub">
                우선 입력 추천: {accuracy.missingTop.map((m) => m.label).join(" · ")}
              </div>
            ) : (
              <div className="mt-3 text-[12.5px] text-ios-sub">
                입력 패턴이 안정적이에요. 계속 유지하면 예측이 더 정교해집니다.
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-ios-sep bg-white p-4">
            <div className="text-[13px] font-semibold">요인별 입력률</div>
            <div className="mt-3 space-y-2">
              {(Object.keys(accuracy.coverage) as FactorKey[]).map((k) => {
                const cov = clamp01(accuracy.coverage[k]);
                const w = clamp01(accuracy.weights[k] ?? 0);
                const alpha = 0.18 + 0.42 * w;
                return (
                  <div key={k} className="rounded-2xl border border-ios-sep bg-ios-bg px-4 py-3">
                    <div className="flex items-center justify-between">
                      <div className="text-[13px] font-semibold">{FACTOR_LABEL_KO[k]}</div>
                      <div className="text-[12.5px] text-ios-muted">{Math.round(cov * 100)}%</div>
                    </div>
                    <div className="mt-2 h-2.5 w-full rounded-full bg-white">
                      <div
                        className="h-2.5 rounded-full"
                        style={{ width: `${cov * 100}%`, backgroundColor: WNL_COLORS.mint, opacity: alpha }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="text-[12.5px] text-ios-muted">
            * Sync는 “최근 7일” 기준입니다. 입력이 쌓이면 Recovery 처방의 근거(수치)가 더 단단해져요.
          </div>
        </div>
      </BottomSheet>
    </InsightDetailShell>
  );
}
