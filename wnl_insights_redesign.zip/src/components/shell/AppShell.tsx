"use client";

import { usePathname } from "next/navigation";
import { BottomNav } from "@/components/shell/BottomNav";
import { AutoHealthLogger } from "@/components/system/AutoHealthLogger";

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-dvh w-full bg-ios-bg">
      <div className="safe-top" />
      {/* 하단 네비게이션/홈 인디케이터에 컨텐츠가 가리지 않도록 safe-area 패딩을 추가 */}
      {/*
        캘린더/차트가 너무 작게 보인다는 피드백 반영:
        - 데스크탑/태블릿에서 더 넓게 보이도록 컨테이너 폭 확장
        - 모바일은 여전히 자연스럽게 full width
      */}
      <div className="mx-auto max-w-[720px] px-4 pb-[calc(96px+env(safe-area-inset-bottom))]">
        <div key={pathname} className="wnl-page-enter">
          {children}
        </div>
      </div>
      {/* 자동 건강 기록/동기화(백그라운드): 매일/실시간 스냅샷 저장 */}
      <AutoHealthLogger />
      <div className="safe-bottom" />
      <BottomNav />
    </div>
  );
}
