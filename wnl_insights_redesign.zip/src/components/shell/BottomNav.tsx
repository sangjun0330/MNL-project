"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/cn";

const ITEMS = [
  { href: "/", label: "홈" },
  { href: "/schedule", label: "일정" },
  { href: "/insights", label: "인사이트" },
  { href: "/settings", label: "설정" },
];

export function BottomNav() {
  const pathname = usePathname();
  const [hide, setHide] = useState(false);

  useEffect(() => {
    if (typeof document !== "undefined") {
      setHide(document.body.classList.contains("wnl-sheet-open"));
    }

    const onSheet = (e: Event) => {
      const ce = e as CustomEvent<{ open: boolean }>;
      setHide(Boolean(ce.detail?.open));
    };
    window.addEventListener("wnl:sheet", onSheet as any);
    return () => window.removeEventListener("wnl:sheet", onSheet as any);
  }, []);

  const activeHref = useMemo(() => {
    const hit = ITEMS.find((it) =>
      it.href === "/" ? pathname === "/" : pathname?.startsWith(it.href)
    );
    return hit?.href ?? "/";
  }, [pathname]);

  if (hide) return null;

  return (
    <div className="fixed inset-x-0 bottom-[calc(14px+env(safe-area-inset-bottom))] z-50 pointer-events-none">
      <div className="mx-auto w-full max-w-md px-4">
        <nav
          className={cn(
            "pointer-events-auto",
            "rounded-full border border-ios-sep bg-white/85",
            "shadow-[0_12px_36px_rgba(0,0,0,0.12)]",
            "backdrop-blur-xl"
          )}
        >
          <div className="grid grid-cols-4 gap-1 p-1.5">
            {ITEMS.map((it) => {
              const active = activeHref === it.href;
              return (
                <Link
                  key={it.href}
                  href={it.href}
                  className={cn(
                    "flex h-11 items-center justify-center rounded-full text-[13px] font-semibold transition",
                    active ? "wnl-nav-active" : "wnl-nav-inactive",
                    active
                      ? "bg-black text-white"
                      : "text-ios-muted hover:bg-black/5"
                  )}
                  aria-current={active ? "page" : undefined}
                >
                  {it.label}
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
